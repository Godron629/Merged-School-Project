<?php 

$serverRoot = $_SERVER['DOCUMENT_ROOT'];
?>