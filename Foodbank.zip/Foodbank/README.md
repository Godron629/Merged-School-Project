# School Project 
A school project for a volunteer management and scheduling system.

It uses PHP, HTML, CSS, JavaScript, and jQuery right now.