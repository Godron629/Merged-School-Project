# School Project 
A school project for a volunteer management and scheduling system.

It features Administrative Only features, a regular user Time Clock, Calendar and Scheduling functionality, and User creation.

It uses PHP, HTML, CSS, JavaScript, and jQuery right now.